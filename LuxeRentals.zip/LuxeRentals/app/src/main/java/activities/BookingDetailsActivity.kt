package com.luxerentals.app.activities

import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.gson.Gson
import com.luxerentals.app.R
import com.luxerentals.app.api.RetrofitClient
import com.luxerentals.app.databinding.ActivityBookingDetailsBinding
import com.luxerentals.app.models.Vehicle
import com.luxerentals.app.utils.SessionManager
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class BookingDetailsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityBookingDetailsBinding
    private lateinit var sessionManager: SessionManager
    private lateinit var vehicle: Vehicle
    private var startDate: String = ""
    private var endDate: String = ""
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityBookingDetailsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Initialize SessionManager FIRST
        sessionManager = SessionManager(this)
        
        // Check if user is logged in
        if (!sessionManager.isLoggedIn()) {
            Toast.makeText(this, "Please login first", Toast.LENGTH_LONG).show()
            val intent = Intent(this, SignInActivity::class.java)
            startActivity(intent)
            finish()
            return
        }

        // Get vehicle from intent
        val vehicleJson = intent.getStringExtra("vehicle_json")
        if (vehicleJson == null) {
            Toast.makeText(this, "Error loading vehicle data", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        
        vehicle = Gson().fromJson(vehicleJson, Vehicle::class.java)

        setupUI()
        setupClickListeners()
        setupPaymentMethodSpinner()
    }

    private fun setupUI() {
        binding.tvVehicleName.text = vehicle.getDisplayName()
        binding.tvDailyRate.text = vehicle.getFormattedPrice()
        binding.tvCategory.text = vehicle.category.uppercase()
    }

    private fun setupClickListeners() {
        binding.btnBack.setOnClickListener {
            finish()
        }

        binding.etStartDate.setOnClickListener {
            showDatePicker(true)
        }

        binding.etEndDate.setOnClickListener {
            showDatePicker(false)
        }

        binding.btnCalculate.setOnClickListener {
            calculateTotal()
        }

        binding.btnConfirmBooking.setOnClickListener {
            confirmBooking()
        }
    }

    private fun setupPaymentMethodSpinner() {
        val paymentMethods = resources.getStringArray(R.array.payment_methods)
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, paymentMethods)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerPaymentMethod.adapter = adapter
    }

    private fun showDatePicker(isStartDate: Boolean) {
        val calendar = Calendar.getInstance()

        val datePickerDialog = DatePickerDialog(
            this,
            { _, year, month, day ->
                calendar.set(year, month, day)
                val date = dateFormat.format(calendar.time)

                if (isStartDate) {
                    startDate = date
                    binding.etStartDate.setText(date)
                } else {
                    endDate = date
                    binding.etEndDate.setText(date)
                }
            },
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH),
            calendar.get(Calendar.DAY_OF_MONTH)
        )

        // Set minimum date to today
        datePickerDialog.datePicker.minDate = System.currentTimeMillis()
        datePickerDialog.show()
    }

    private fun calculateTotal() {
        if (startDate.isEmpty() || endDate.isEmpty()) {
            Toast.makeText(this, "Please select both start and end dates", Toast.LENGTH_SHORT).show()
            return
        }

        try {
            val start = dateFormat.parse(startDate)
            val end = dateFormat.parse(endDate)

            if (end != null && start != null) {
                if (end.before(start)) {
                    Toast.makeText(this, "End date must be after start date", Toast.LENGTH_SHORT).show()
                    return
                }

                val days = ((end.time - start.time) / (1000 * 60 * 60 * 24)).toInt() + 1
                val total = days * vehicle.dailyRate
                val deposit = total * 0.30

                binding.tvTotalDays.text = "$days days"
                binding.tvTotalAmount.text = "₱${String.format("%.2f", total)}"
                binding.tvDepositAmount.text = "₱${String.format("%.2f", deposit)}"

                binding.layoutCalculation.visibility = View.VISIBLE
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Error calculating dates: ${e.message}", Toast.LENGTH_SHORT).show()
            e.printStackTrace()
        }
    }

    private fun confirmBooking() {
        if (!validateInput()) return

        // Get user ID from session
        val userId = sessionManager.getUserId()
        
        // Double-check user is logged in
        if (userId == 0) {
            Toast.makeText(this, "Session expired. Please login again.", Toast.LENGTH_LONG).show()
            val intent = Intent(this, SignInActivity::class.java)
            startActivity(intent)
            finish()
            return
        }

        binding.progressBar.visibility = View.VISIBLE
        binding.btnConfirmBooking.isEnabled = false

        lifecycleScope.launch {
            try {
                // Get selected payment method
                val paymentMethodIndex = binding.spinnerPaymentMethod.selectedItemPosition
                val paymentMethods = resources.getStringArray(R.array.payment_methods)
                val paymentMethod = paymentMethods[paymentMethodIndex]

                // Create booking data - ALL values as strings
                val bookingData = hashMapOf(
                    "user_id" to userId.toString(),
                    "vehicle_id" to vehicle.vehicleId.toString(),
                    "start_date" to startDate,
                    "end_date" to endDate,
                    "pickup_location" to binding.etPickupLocation.text.toString().trim(),
                    "dropoff_location" to binding.etDropoffLocation.text.toString().trim(),
                    "payment_method" to paymentMethod.lowercase(Locale.getDefault()).replace(" ", "_")
                )

                // Log the data being sent (for debugging)
                Log.d("BookingDetails", "Sending booking data: $bookingData")

                val response = RetrofitClient.apiService.createBooking(bookingData)

                binding.progressBar.visibility = View.GONE
                binding.btnConfirmBooking.isEnabled = true

                if (response.isSuccessful) {
                    val bookingResponse = response.body()

                    if (bookingResponse?.success == true) {
                        // Go to success screen
                        val intent = Intent(this@BookingDetailsActivity, BookingSuccessActivity::class.java)
                        intent.putExtra("booking_data", Gson().toJson(bookingResponse.data))
                        startActivity(intent)
                        finish()
                    } else {
                        Toast.makeText(
                            this@BookingDetailsActivity,
                            bookingResponse?.message ?: "Booking failed",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                } else {
                    Toast.makeText(
                        this@BookingDetailsActivity,
                        "Server error: ${response.code()} - ${response.message()}",
                        Toast.LENGTH_LONG
                    ).show()
                }

            } catch (e: Exception) {
                binding.progressBar.visibility = View.GONE
                binding.btnConfirmBooking.isEnabled = true

                Toast.makeText(
                    this@BookingDetailsActivity,
                    "Error: ${e.message}",
                    Toast.LENGTH_LONG
                ).show()
                Log.e("BookingDetails", "Error creating booking", e)
                e.printStackTrace()
            }
        }
    }

    private fun validateInput(): Boolean {
        if (startDate.isEmpty()) {
            Toast.makeText(this, "Please select start date", Toast.LENGTH_SHORT).show()
            return false
        }

        if (endDate.isEmpty()) {
            Toast.makeText(this, "Please select end date", Toast.LENGTH_SHORT).show()
            return false
        }

        val pickupLocation = binding.etPickupLocation.text.toString().trim()
        if (pickupLocation.isEmpty()) {
            binding.etPickupLocation.error = "Pickup location is required"
            return false
        }

        val dropoffLocation = binding.etDropoffLocation.text.toString().trim()
        if (dropoffLocation.isEmpty()) {
            binding.etDropoffLocation.error = "Dropoff location is required"
            return false
        }

        if (binding.layoutCalculation.visibility != View.VISIBLE) {
            Toast.makeText(this, "Please calculate total first", Toast.LENGTH_SHORT).show()
            return false
        }

        return true
    }
}
