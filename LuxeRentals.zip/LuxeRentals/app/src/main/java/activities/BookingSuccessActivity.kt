package com.luxerentals.app.activities

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.luxerentals.app.databinding.ActivityBookingSuccessBinding
import com.luxerentals.app.models.BookingData
import com.google.gson.Gson
import java.text.SimpleDateFormat
import java.util.Locale

class BookingSuccessActivity : AppCompatActivity() {
    
    private lateinit var binding: ActivityBookingSuccessBinding
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityBookingSuccessBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        val bookingJson = intent.getStringExtra("booking_data")
        val bookingData = Gson().fromJson(bookingJson, BookingData::class.java)
        
        displayBookingInfo(bookingData)
        
        binding.btnBackHome.setOnClickListener {
            val intent = Intent(this, HomeActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
            startActivity(intent)
            finish()
        }
    }
    
    private fun displayBookingInfo(data: BookingData) {
        binding.tvBookingId.text = "#${data.rentalId}"
        binding.tvVehicle.text = data.vehicleName
        
        try {
            // Parse dates from string format (yyyy-MM-dd)
            val inputFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            val outputFormat = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())
            
            val startDate = inputFormat.parse(data.startDate)
            val endDate = inputFormat.parse(data.endDate)
            
            val startDateStr = if (startDate != null) outputFormat.format(startDate) else data.startDate
            val endDateStr = if (endDate != null) outputFormat.format(endDate) else data.endDate
            
            binding.tvDates.text = "$startDateStr - $endDateStr"
        } catch (e: Exception) {
            // If parsing fails, just show the original strings
            binding.tvDates.text = "${data.startDate} - ${data.endDate}"
        }
        
        binding.tvDays.text = "${data.totalDays} days"
        binding.tvTotal.text = String.format(Locale.getDefault(), "₱%.2f", data.totalAmount)
    }
    
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // Prevent going back to prevent double booking
        val intent = Intent(this, HomeActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
        startActivity(intent)
        finish()
    }
}
