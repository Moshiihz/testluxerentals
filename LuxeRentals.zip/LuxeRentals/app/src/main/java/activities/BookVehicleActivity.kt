package com.luxerentals.app.activities

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.gson.Gson
import com.luxerentals.app.adapters.VehicleAdapter
import com.luxerentals.app.api.RetrofitClient
import com.luxerentals.app.databinding.ActivityBookVehicleBinding
import com.luxerentals.app.models.Vehicle
import kotlinx.coroutines.launch

class BookVehicleActivity : AppCompatActivity() {

    private lateinit var binding: ActivityBookVehicleBinding
    private lateinit var vehicleAdapter: VehicleAdapter
    private val vehicles = mutableListOf<Vehicle>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityBookVehicleBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupRecyclerView()
        setupClickListeners()
        loadVehicles()
    }

    private fun setupRecyclerView() {
        vehicleAdapter = VehicleAdapter(vehicles) { vehicle ->
            openBookingDetails(vehicle)
        }

        binding.recyclerVehicles.apply {
            layoutManager = LinearLayoutManager(this@BookVehicleActivity)
            adapter = vehicleAdapter
        }
    }

    private fun setupClickListeners() {
        binding.btnBack.setOnClickListener {
            finish()
        }

        binding.swipeRefresh.setOnRefreshListener {
            loadVehicles()
        }
    }

    private fun loadVehicles() {
        binding.swipeRefresh.isRefreshing = true
        binding.progressBar.visibility = View.VISIBLE

        lifecycleScope.launch {
            try {
                val response = RetrofitClient.apiService.getAvailableVehicles()

                binding.swipeRefresh.isRefreshing = false
                binding.progressBar.visibility = View.GONE

                if (response.isSuccessful) {
                    val vehicleList = response.body() ?: emptyList()

                    if (vehicleList.isEmpty()) {
                        binding.tvNoVehicles.visibility = View.VISIBLE
                        binding.recyclerVehicles.visibility = View.GONE
                    } else {
                        binding.tvNoVehicles.visibility = View.GONE
                        binding.recyclerVehicles.visibility = View.VISIBLE

                        vehicles.clear()
                        vehicles.addAll(vehicleList)
                        vehicleAdapter.notifyDataSetChanged()
                    }
                } else {
                    Toast.makeText(
                        this@BookVehicleActivity,
                        "Failed to load vehicles: ${response.code()}",
                        Toast.LENGTH_SHORT
                    ).show()
                }

            } catch (e: Exception) {
                binding.swipeRefresh.isRefreshing = false
                binding.progressBar.visibility = View.GONE

                Toast.makeText(
                    this@BookVehicleActivity,
                    "Error: ${e.message}",
                    Toast.LENGTH_SHORT
                ).show()
                e.printStackTrace()
            }
        }
    }

    private fun openBookingDetails(vehicle: Vehicle) {
        val intent = Intent(this, BookingDetailsActivity::class.java)
        intent.putExtra("vehicle_json", Gson().toJson(vehicle))
        startActivity(intent)
    }
}
