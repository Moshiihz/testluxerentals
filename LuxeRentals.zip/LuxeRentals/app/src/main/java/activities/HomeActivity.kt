package com.luxerentals.app.activities

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.luxerentals.app.api.RetrofitClient
import com.luxerentals.app.databinding.ActivityHomeBinding
import com.luxerentals.app.utils.SessionManager
import kotlinx.coroutines.launch

class HomeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityHomeBinding
    private lateinit var sessionManager: SessionManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        sessionManager = SessionManager(this)

        // Check if user is logged in
        if (!sessionManager.isLoggedIn()) {
            navigateToLogin()
            return
        }

        setupUI()
        setupClickListeners()
        loadActiveRental()
    }

    private fun setupUI() {
        // Display user name
        val userName = sessionManager.getFullName()
        binding.tvWelcome.text = "Welcome, $userName"
        // REMOVED: binding.tvSubtitle - doesn't exist in your XML
    }

    private fun setupClickListeners() {
        // REMOVED: binding.btnMenu - doesn't exist in your XML

        binding.btnBookVehicle.setOnClickListener {
            val intent = Intent(this, BookVehicleActivity::class.java)
            startActivity(intent)
        }

        binding.swipeRefresh.setOnRefreshListener {
            loadActiveRental()
        }
    }

    private fun logout() {
        sessionManager.logout()
        navigateToLogin()
    }

    private fun navigateToLogin() {
        val intent = Intent(this, SignInActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }

    private fun loadActiveRental() {
        binding.swipeRefresh.isRefreshing = true
        binding.progressBar.visibility = View.VISIBLE

        lifecycleScope.launch {
            try {
                val userId = sessionManager.getUserId()
                val response = RetrofitClient.apiService.getActiveRental(userId)

                binding.swipeRefresh.isRefreshing = false
                binding.progressBar.visibility = View.GONE

                if (response.isSuccessful) {
                    val rentalResponse = response.body()

                    if (rentalResponse?.success == true && rentalResponse.rental != null) {
                        // Has active rental
                        binding.tvNoRental.visibility = View.GONE
                        binding.cardActiveRental.visibility = View.VISIBLE
                        displayActiveRental(rentalResponse.rental)
                    } else {
                        // No active rental
                        binding.tvNoRental.visibility = View.VISIBLE
                        binding.cardActiveRental.visibility = View.GONE
                    }
                } else {
                    binding.tvNoRental.visibility = View.VISIBLE
                    binding.cardActiveRental.visibility = View.GONE
                }

            } catch (e: Exception) {
                binding.swipeRefresh.isRefreshing = false
                binding.progressBar.visibility = View.GONE
                binding.tvNoRental.visibility = View.VISIBLE
                binding.cardActiveRental.visibility = View.GONE

                Toast.makeText(
                    this@HomeActivity,
                    "Error loading rental: ${e.message}",
                    Toast.LENGTH_SHORT
                ).show()
                e.printStackTrace()
            }
        }
    }

    private fun displayActiveRental(rental: com.luxerentals.app.models.Rental) {
        binding.tvVehicleName.text = "${rental.vehicleBrand} ${rental.vehicleModel}"
        binding.tvRentalDates.text = "${rental.startDate} - ${rental.endDate}"
        // REMOVED: binding.tvRentalTotal - doesn't exist in your XML
        // REMOVED: binding.tvRentalStatus - doesn't exist in your XML
        // REMOVED: binding.btnCancelRental - doesn't exist in your XML
    }
}