package com.luxerentals.app.activities

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.luxerentals.app.api.RetrofitClient
import com.luxerentals.app.databinding.ActivitySignInBinding
import com.luxerentals.app.utils.SessionManager
import kotlinx.coroutines.launch

class SignInActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySignInBinding
    private lateinit var sessionManager: SessionManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySignInBinding.inflate(layoutInflater)
        setContentView(binding.root)

        sessionManager = SessionManager(this)

        // Check if already logged in
        if (sessionManager.isLoggedIn()) {
            navigateToHome()
            return
        }

        setupClickListeners()
    }

    private fun setupClickListeners() {
        binding.btnSignIn.setOnClickListener {
            performLogin()
        }

        binding.tvSignUp.setOnClickListener {
            val intent = Intent(this, SignUpActivity::class.java)
            startActivity(intent)
        }
    }

    private fun performLogin() {
        val email = binding.etEmail.text.toString().trim()
        val password = binding.etPassword.text.toString().trim()

        // Validate input
        if (email.isEmpty()) {
            binding.etEmail.error = "Email is required"
            return
        }

        if (password.isEmpty()) {
            binding.etPassword.error = "Password is required"
            return
        }

        // Show loading
        binding.progressBar.visibility = View.VISIBLE
        binding.btnSignIn.isEnabled = false

        lifecycleScope.launch {
            try {
                val credentials = mapOf(
                    "email" to email,
                    "password" to password
                )

                val response = RetrofitClient.apiService.login(credentials)

                binding.progressBar.visibility = View.GONE
                binding.btnSignIn.isEnabled = true

                if (response.isSuccessful) {
                    val loginResponse = response.body()

                    if (loginResponse?.success == true && loginResponse.user != null) {
                        // Get the user object from response
                        val user = loginResponse.user

                        // CRITICAL: Save session with user data
                        // The SessionManager will handle converting User to the format it needs
                        sessionManager.saveLoginSession(user)

                        // Verify session was saved
                        val savedUserId = sessionManager.getUserId()
                        val savedName = sessionManager.getFullName()
                        Log.d("SignIn", "User logged in - ID: $savedUserId, Name: $savedName")

                        if (savedUserId == 0) {
                            // Session didn't save properly!
                            Toast.makeText(
                                this@SignInActivity,
                                "Error saving session. Please try again.",
                                Toast.LENGTH_LONG
                            ).show()
                            return@launch
                        }

                        Toast.makeText(
                            this@SignInActivity,
                            "Welcome back!",
                            Toast.LENGTH_SHORT
                        ).show()

                        // Navigate based on user role
                        if (sessionManager.isAdmin()) {
                            navigateToAdminDashboard()
                        } else {
                            navigateToHome()
                        }
                    } else {
                        Toast.makeText(
                            this@SignInActivity,
                            loginResponse?.message ?: "Login failed",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                } else {
                    Toast.makeText(
                        this@SignInActivity,
                        "Server error: ${response.code()}",
                        Toast.LENGTH_LONG
                    ).show()
                }

            } catch (e: Exception) {
                binding.progressBar.visibility = View.GONE
                binding.btnSignIn.isEnabled = true

                Toast.makeText(
                    this@SignInActivity,
                    "Error: ${e.message}",
                    Toast.LENGTH_LONG
                ).show()
                Log.e("SignIn", "Login error", e)
                e.printStackTrace()
            }
        }
    }

    private fun navigateToHome() {
        val intent = Intent(this, HomeActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }

    private fun navigateToAdminDashboard() {
        val intent = Intent(this, AdminDashboardActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }
}
