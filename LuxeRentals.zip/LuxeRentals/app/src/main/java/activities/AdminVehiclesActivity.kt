package com.luxerentals.app.activities

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.luxerentals.app.adapters.AdminVehicleAdapter
import com.luxerentals.app.api.RetrofitClient
import com.luxerentals.app.databinding.ActivityAdminVehiclesBinding
import com.luxerentals.app.models.Vehicle
import kotlinx.coroutines.launch

class AdminVehiclesActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAdminVehiclesBinding
    private lateinit var vehicleAdapter: AdminVehicleAdapter
    private val vehicles = mutableListOf<Vehicle>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAdminVehiclesBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupRecyclerView()
        setupClickListeners()
        loadVehicles()
    }

    private fun setupRecyclerView() {
        vehicleAdapter = AdminVehicleAdapter(
            vehicles = vehicles,
            onEdit = { vehicle -> editVehicle(vehicle) },
            onDelete = { vehicle -> confirmDelete(vehicle) }
        )

        binding.recyclerVehicles.apply {
            layoutManager = LinearLayoutManager(this@AdminVehiclesActivity)
            adapter = vehicleAdapter
        }
    }

    private fun setupClickListeners() {
        binding.btnBack.setOnClickListener {
            finish()
        }

        binding.btnAddVehicle.setOnClickListener {
            addVehicle()
        }

        binding.swipeRefresh.setOnRefreshListener {
            loadVehicles()
        }
    }

    private fun addVehicle() {
        Toast.makeText(
            this,
            "Add Vehicle - Use web app or database for now. Mobile form coming soon!",
            Toast.LENGTH_LONG
        ).show()
        
        // TODO: Implement add vehicle dialog or activity
        // For now, direct user to web app
    }

    private fun editVehicle(vehicle: Vehicle) {
        Toast.makeText(
            this,
            "Edit ${vehicle.getDisplayName()} - Use web app for now. Mobile edit coming soon!",
            Toast.LENGTH_LONG
        ).show()
        
        // TODO: Implement edit dialog or navigate to edit activity
    }

    private fun confirmDelete(vehicle: Vehicle) {
        AlertDialog.Builder(this)
            .setTitle("Delete Vehicle")
            .setMessage("Are you sure you want to delete ${vehicle.getDisplayName()}?\n\nPlate: ${vehicle.plateNumber}\n\nThis action cannot be undone!")
            .setPositiveButton("DELETE") { _, _ ->
                deleteVehicle(vehicle)
            }
            .setNegativeButton("CANCEL", null)
            .show()
    }

    private fun deleteVehicle(vehicle: Vehicle) {
        showLoading(true)

        lifecycleScope.launch {
            try {
                val response = RetrofitClient.apiService.deleteVehicle(vehicle.vehicleId)

                showLoading(false)

                if (response.isSuccessful) {
                    val result = response.body()

                    if (result?.success == true) {
                        Toast.makeText(
                            this@AdminVehiclesActivity,
                            "Vehicle deleted successfully!",
                            Toast.LENGTH_SHORT
                        ).show()

                        // Remove from list immediately
                        val position = vehicles.indexOf(vehicle)
                        if (position != -1) {
                            vehicles.removeAt(position)
                            vehicleAdapter.notifyItemRemoved(position)
                        }

                        // Update empty state
                        if (vehicles.isEmpty()) {
                            binding.tvNoVehicles.visibility = View.VISIBLE
                            binding.recyclerVehicles.visibility = View.GONE
                        }
                    } else {
                        Toast.makeText(
                            this@AdminVehiclesActivity,
                            result?.message ?: "Failed to delete vehicle",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                } else {
                    Toast.makeText(
                        this@AdminVehiclesActivity,
                        "Server error: ${response.code()}",
                        Toast.LENGTH_LONG
                    ).show()
                }

            } catch (e: Exception) {
                showLoading(false)
                Toast.makeText(
                    this@AdminVehiclesActivity,
                    "Error: ${e.message}",
                    Toast.LENGTH_LONG
                ).show()
                e.printStackTrace()
            }
        }
    }

    private fun loadVehicles() {
        showLoading(true)
        binding.swipeRefresh.isRefreshing = false

        lifecycleScope.launch {
            try {
                val response = RetrofitClient.apiService.getAllVehicles()

                showLoading(false)

                if (response.isSuccessful) {
                    val vehicleList = response.body() ?: emptyList()

                    vehicles.clear()
                    vehicles.addAll(vehicleList)
                    vehicleAdapter.notifyDataSetChanged()

                    if (vehicleList.isEmpty()) {
                        binding.tvNoVehicles.visibility = View.VISIBLE
                        binding.recyclerVehicles.visibility = View.GONE
                    } else {
                        binding.tvNoVehicles.visibility = View.GONE
                        binding.recyclerVehicles.visibility = View.VISIBLE
                    }
                } else {
                    Toast.makeText(
                        this@AdminVehiclesActivity,
                        "Failed to load vehicles: ${response.code()}",
                        Toast.LENGTH_SHORT
                    ).show()
                }

            } catch (e: Exception) {
                showLoading(false)
                Toast.makeText(
                    this@AdminVehiclesActivity,
                    "Error: ${e.message}",
                    Toast.LENGTH_SHORT
                ).show()
                e.printStackTrace()
            }
        }
    }

    private fun showLoading(isLoading: Boolean) {
        binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
    }
}
