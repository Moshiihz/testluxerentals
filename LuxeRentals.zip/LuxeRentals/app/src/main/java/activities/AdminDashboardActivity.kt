package com.luxerentals.app.activities

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.luxerentals.app.databinding.ActivityAdminDashboardBinding
import com.luxerentals.app.adapters.RentalAdapter
import com.luxerentals.app.api.RetrofitClient
import com.luxerentals.app.models.Rental
import com.luxerentals.app.utils.SessionManager
import kotlinx.coroutines.launch
import java.util.Locale

class AdminDashboardActivity : AppCompatActivity() {
    
    private lateinit var binding: ActivityAdminDashboardBinding
    private lateinit var sessionManager: SessionManager
    private lateinit var rentalAdapter: RentalAdapter
    private val rentals = mutableListOf<Rental>()
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAdminDashboardBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        sessionManager = SessionManager(this)
        
        setupRecyclerView()
        setupClickListeners()
        loadDashboardData()
    }
    
    private fun setupRecyclerView() {
        rentalAdapter = RentalAdapter(
            rentals = rentals,
            onApprove = { rental -> approveRental(rental.rentalId) },
            onDeny = { rental -> denyRental(rental.rentalId) },
            onDelete = { rental -> deleteBooking(rental.rentalId) }
        )
        
        binding.recyclerRentals.apply {
            layoutManager = LinearLayoutManager(this@AdminDashboardActivity)
            adapter = rentalAdapter
        }
    }
    
    private fun setupClickListeners() {
        binding.btnLogout.setOnClickListener {
            logout()
        }
        
        binding.btnManageVehicles.setOnClickListener {
            val intent = Intent(this, AdminVehiclesActivity::class.java)
            startActivity(intent)
        }
        
        binding.swipeRefresh.setOnRefreshListener {
            loadDashboardData()
        }
    }
    
    private fun loadDashboardData() {
        showLoading(true)
        binding.swipeRefresh.isRefreshing = false
        
        lifecycleScope.launch {
            try {
                // Load rentals
                val rentalsResponse = RetrofitClient.apiService.getAllRentals()
                
                // Load earnings
                val earningsResponse = RetrofitClient.apiService.getEarnings()
                
                showLoading(false)
                
                if (rentalsResponse.isSuccessful) {
                    val rentalsData = rentalsResponse.body()
                    
                    if (rentalsData?.success == true) {
                        rentals.clear()
                        rentalsData.rentals?.let { rentals.addAll(it) }
                        rentalAdapter.notifyDataSetChanged()
                        
                        if (rentals.isEmpty()) {
                            binding.tvNoRentals.visibility = View.VISIBLE
                            binding.recyclerRentals.visibility = View.GONE
                        } else {
                            binding.tvNoRentals.visibility = View.GONE
                            binding.recyclerRentals.visibility = View.VISIBLE
                        }
                    }
                }
                
                if (earningsResponse.isSuccessful) {
                    val earnings = earningsResponse.body()
                    
                    if (earnings?.success == true) {
                        // Use the direct fields from EarningsResponse
                        binding.tvTodayEarnings.text = String.format(
                            Locale.getDefault(),
                            "₱%.2f",
                            earnings.todayEarnings
                        )
                        binding.tvTotalEarnings.text = String.format(
                            Locale.getDefault(),
                            "₱%.2f",
                            earnings.totalEarnings
                        )
                        
                        // Use statistics object if available, otherwise use direct fields
                        val totalBookings = earnings.statistics?.totalBookings ?: 0
                        val pendingBookings = earnings.statistics?.pendingBookings ?: 0
                        
                        binding.tvTotalBookings.text = "$totalBookings"
                        binding.tvPendingBookings.text = "$pendingBookings"
                    }
                }
                
            } catch (e: Exception) {
                showLoading(false)
                Toast.makeText(
                    this@AdminDashboardActivity,
                    "Error: ${e.message}",
                    Toast.LENGTH_LONG
                ).show()
                e.printStackTrace()
            }
        }
    }
    
    private fun approveRental(rentalId: Int) {
        lifecycleScope.launch {
            try {
                val response = RetrofitClient.apiService.approveRental(
                    rentalId = rentalId,
                    action = "approve"
                )
                
                if (response.isSuccessful) {
                    val result = response.body()
                    
                    Toast.makeText(
                        this@AdminDashboardActivity,
                        result?.message ?: "Approved",
                        Toast.LENGTH_SHORT
                    ).show()
                    loadDashboardData()
                } else {
                    Toast.makeText(
                        this@AdminDashboardActivity,
                        "Error: ${response.code()}",
                        Toast.LENGTH_LONG
                    ).show()
                }
                
            } catch (e: Exception) {
                Toast.makeText(
                    this@AdminDashboardActivity,
                    "Error: ${e.message}",
                    Toast.LENGTH_LONG
                ).show()
                e.printStackTrace()
            }
        }
    }
    
    private fun denyRental(rentalId: Int) {
        lifecycleScope.launch {
            try {
                val response = RetrofitClient.apiService.approveRental(
                    rentalId = rentalId,
                    action = "deny"
                )
                
                if (response.isSuccessful) {
                    val result = response.body()
                    
                    Toast.makeText(
                        this@AdminDashboardActivity,
                        result?.message ?: "Denied",
                        Toast.LENGTH_SHORT
                    ).show()
                    loadDashboardData()
                } else {
                    Toast.makeText(
                        this@AdminDashboardActivity,
                        "Error: ${response.code()}",
                        Toast.LENGTH_LONG
                    ).show()
                }
                
            } catch (e: Exception) {
                Toast.makeText(
                    this@AdminDashboardActivity,
                    "Error: ${e.message}",
                    Toast.LENGTH_LONG
                ).show()
                e.printStackTrace()
            }
        }
    }
    
    private fun deleteBooking(rentalId: Int) {
        AlertDialog.Builder(this)
            .setTitle("Delete Booking")
            .setMessage("Are you sure you want to delete this booking?")
            .setPositiveButton("Delete") { _, _ ->
                performDelete(rentalId)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
    
    private fun performDelete(rentalId: Int) {
        lifecycleScope.launch {
            try {
                val response = RetrofitClient.apiService.deleteBooking(rentalId)
                
                if (response.isSuccessful) {
                    val result = response.body()
                    
                    Toast.makeText(
                        this@AdminDashboardActivity,
                        result?.message ?: "Deleted",
                        Toast.LENGTH_SHORT
                    ).show()
                    loadDashboardData()
                } else {
                    Toast.makeText(
                        this@AdminDashboardActivity,
                        "Error: ${response.code()}",
                        Toast.LENGTH_LONG
                    ).show()
                }
                
            } catch (e: Exception) {
                Toast.makeText(
                    this@AdminDashboardActivity,
                    "Error: ${e.message}",
                    Toast.LENGTH_LONG
                ).show()
                e.printStackTrace()
            }
        }
    }
    
    private fun logout() {
        sessionManager.logout()
        val intent = Intent(this, SignInActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }
    
    private fun showLoading(isLoading: Boolean) {
        binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
    }
}
