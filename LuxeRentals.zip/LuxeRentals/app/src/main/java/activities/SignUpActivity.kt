package com.luxerentals.app.activities

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.luxerentals.app.api.RetrofitClient
import com.luxerentals.app.databinding.ActivitySignUpBinding
import com.luxerentals.app.utils.SessionManager
import kotlinx.coroutines.launch

class SignUpActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySignUpBinding
    private lateinit var sessionManager: SessionManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySignUpBinding.inflate(layoutInflater)
        setContentView(binding.root)

        sessionManager = SessionManager(this)

        // REMOVED: setupCountrySpinner() - doesn't exist in your XML
        setupClickListeners()
    }

    private fun setupClickListeners() {
        binding.btnSignUp.setOnClickListener {
            performSignUp()
        }

        binding.tvSignIn.setOnClickListener {
            finish()
        }
    }

    private fun performSignUp() {
        val fullName = binding.etFullName.text.toString().trim()
        val email = binding.etEmail.text.toString().trim()
        val phone = binding.etPhone.text.toString().trim()
        // CHANGED: Hardcode country since spinner doesn't exist
        val country = binding.etCountry.text.toString().trim().ifEmpty { "Philippines" }
        val password = binding.etPassword.text.toString().trim()
        val confirmPassword = binding.etConfirmPassword.text.toString().trim()

        // Validation
        if (fullName.isEmpty()) {
            binding.etFullName.error = "Full name is required"
            return
        }

        if (email.isEmpty()) {
            binding.etEmail.error = "Email is required"
            return
        }

        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            binding.etEmail.error = "Invalid email address"
            return
        }

        if (phone.isEmpty()) {
            binding.etPhone.error = "Phone number is required"
            return
        }

        if (password.isEmpty()) {
            binding.etPassword.error = "Password is required"
            return
        }

        if (password.length < 6) {
            binding.etPassword.error = "Password must be at least 6 characters"
            return
        }

        if (password != confirmPassword) {
            binding.etConfirmPassword.error = "Passwords do not match"
            return
        }

        // Show loading
        binding.progressBar.visibility = View.VISIBLE
        binding.btnSignUp.isEnabled = false

        lifecycleScope.launch {
            try {
                // Create user data map
                val userData = mapOf(
                    "full_name" to fullName,
                    "email" to email,
                    "phone" to phone,
                    "country" to country,
                    "password" to password
                )

                val response = RetrofitClient.apiService.signup(userData)

                binding.progressBar.visibility = View.GONE
                binding.btnSignUp.isEnabled = true

                if (response.isSuccessful) {
                    val signupResponse = response.body()

                    if (signupResponse?.success == true && signupResponse.user != null) {
                        // Signup successful
                        val user = signupResponse.user

                        // Save session
                        sessionManager.saveLoginSession(user)

                        // Verify session
                        val savedUserId = sessionManager.getUserId()
                        Log.d("SignUp", "User signed up - ID: $savedUserId")

                        Toast.makeText(
                            this@SignUpActivity,
                            "Account created successfully!",
                            Toast.LENGTH_SHORT
                        ).show()

                        // Navigate to home
                        val intent = Intent(this@SignUpActivity, HomeActivity::class.java)
                        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                        startActivity(intent)
                        finish()
                    } else {
                        Toast.makeText(
                            this@SignUpActivity,
                            signupResponse?.message ?: "Sign up failed",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                } else {
                    Toast.makeText(
                        this@SignUpActivity,
                        "Server error: ${response.code()}",
                        Toast.LENGTH_LONG
                    ).show()
                }

            } catch (e: Exception) {
                binding.progressBar.visibility = View.GONE
                binding.btnSignUp.isEnabled = true

                Toast.makeText(
                    this@SignUpActivity,
                    "Error: ${e.message}",
                    Toast.LENGTH_LONG
                ).show()
                Log.e("SignUp", "Signup error", e)
                e.printStackTrace()
            }
        }
    }
}