package com.luxerentals.app.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.luxerentals.app.databinding.ItemVehicleBinding
import com.luxerentals.app.models.Vehicle

class VehicleAdapter(
    private val vehicles: List<Vehicle>,
    private val onVehicleClick: (Vehicle) -> Unit
) : RecyclerView.Adapter<VehicleAdapter.VehicleViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VehicleViewHolder {
        val binding = ItemVehicleBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return VehicleViewHolder(binding)
    }

    override fun onBindViewHolder(holder: VehicleViewHolder, position: Int) {
        holder.bind(vehicles[position])
    }

    override fun getItemCount(): Int = vehicles.size

    inner class VehicleViewHolder(
        private val binding: ItemVehicleBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(vehicle: Vehicle) {
            // Set vehicle data
            binding.tvVehicleName.text = vehicle.getDisplayName()
            binding.tvCategory.text = vehicle.category.uppercase()
            binding.tvYear.text = vehicle.year.toString()
            binding.tvSeats.text = vehicle.seats.toString()
            binding.tvTransmission.text = vehicle.transmission
            binding.tvFuelType.text = vehicle.fuelType
            binding.tvPrice.text = String.format("₱%.2f", vehicle.dailyRate)
            binding.tvPriceUnit.text = "/day"

            // Enable and set click listener on BOOK NOW button
            binding.btnBookNow.isEnabled = true
            binding.btnBookNow.setOnClickListener {
                onVehicleClick(vehicle)
            }
            
            // Also make card clickable
            binding.root.setOnClickListener {
                onVehicleClick(vehicle)
            }
        }
    }
}
