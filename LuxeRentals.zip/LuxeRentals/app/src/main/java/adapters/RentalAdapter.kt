package com.luxerentals.app.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.luxerentals.app.R
import com.luxerentals.app.databinding.ItemRentalBinding
import com.luxerentals.app.models.Rental
import java.text.SimpleDateFormat
import java.util.*

class RentalAdapter(
    private val rentals: List<Rental>,
    private val onApprove: (Rental) -> Unit,
    private val onDeny: (Rental) -> Unit,
    private val onDelete: (Rental) -> Unit
) : RecyclerView.Adapter<RentalAdapter.RentalViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RentalViewHolder {
        val binding = ItemRentalBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return RentalViewHolder(binding)
    }

    override fun onBindViewHolder(holder: RentalViewHolder, position: Int) {
        holder.bind(rentals[position])
    }

    override fun getItemCount(): Int = rentals.size

    inner class RentalViewHolder(
        private val binding: ItemRentalBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(rental: Rental) {
            // Rental ID
            binding.tvRentalId.text = itemView.context.getString(
                R.string.rental_id_format,
                rental.rentalId
            )

            // User name
            binding.tvUserName.text = rental.userName

            // Vehicle name (brand + model)
            val vehicleName = "${rental.vehicleBrand} ${rental.vehicleModel}"
            binding.tvVehicle.text = vehicleName

            // Status
            binding.tvStatus.text = rental.status.uppercase(Locale.getDefault())
            binding.tvStatus.setBackgroundColor(rental.getStatusColor())

            // Format dates
            val dateFormat = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())
            val startDate = dateFormat.format(rental.startDate)
            val endDate = dateFormat.format(rental.endDate)
            val datesText = "$startDate to $endDate"
            binding.tvDates.text = datesText

            // Total amount
            binding.tvTotalAmount.text = rental.getFormattedTotal()

            // Action buttons visibility
            if (rental.status.equals("pending", ignoreCase = true)) {
                binding.layoutActions.visibility = View.VISIBLE
                
                binding.btnApprove.setOnClickListener {
                    onApprove(rental)
                }
                
                binding.btnDeny.setOnClickListener {
                    onDeny(rental)
                }
            } else {
                binding.layoutActions.visibility = View.GONE
            }

            // Delete button always visible for admin
            binding.btnDelete.setOnClickListener {
                onDelete(rental)
            }
        }
    }
}
