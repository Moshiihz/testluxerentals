package com.luxerentals.app.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.luxerentals.app.databinding.ItemAdminVehicleBinding
import com.luxerentals.app.models.Vehicle

class AdminVehicleAdapter(
    private val vehicles: List<Vehicle>,
    private val onEdit: (Vehicle) -> Unit,
    private val onDelete: (Vehicle) -> Unit
) : RecyclerView.Adapter<AdminVehicleAdapter.AdminVehicleViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AdminVehicleViewHolder {
        val binding = ItemAdminVehicleBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return AdminVehicleViewHolder(binding)
    }

    override fun onBindViewHolder(holder: AdminVehicleViewHolder, position: Int) {
        holder.bind(vehicles[position])
    }

    override fun getItemCount(): Int = vehicles.size

    inner class AdminVehicleViewHolder(
        private val binding: ItemAdminVehicleBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(vehicle: Vehicle) {
            // Set vehicle data
            binding.tvVehicleName.text = vehicle.getDisplayName()
            binding.tvCategory.text = vehicle.category.uppercase()
            binding.tvStatus.text = vehicle.status.uppercase()
            binding.tvYear.text = vehicle.year.toString()
            binding.tvSeats.text = vehicle.seats.toString()
            binding.tvTransmission.text = vehicle.transmission
            binding.tvFuelType.text = vehicle.fuelType
            binding.tvPlateNumber.text = vehicle.plateNumber
            binding.tvPrice.text = String.format("₱%.2f", vehicle.dailyRate)
            binding.tvPriceUnit.text = "/day"

            // Status color
            when (vehicle.status.lowercase()) {
                "available" -> binding.tvStatus.setTextColor(0xFF10B981.toInt())
                "rented" -> binding.tvStatus.setTextColor(0xFFFFB800.toInt())
                "maintenance" -> binding.tvStatus.setTextColor(0xFFEF4444.toInt())
                else -> binding.tvStatus.setTextColor(0xFF6B7280.toInt())
            }

            // EDIT button
            binding.btnEdit.setOnClickListener {
                onEdit(vehicle)
            }

            // DELETE button
            binding.btnDelete.setOnClickListener {
                onDelete(vehicle)
            }
        }
    }
}
