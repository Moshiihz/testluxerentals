package com.luxerentals.app.utils

import android.content.Context
import android.content.SharedPreferences
import com.luxerentals.app.models.User

class SessionManager(context: Context) {
    
    private val prefs: SharedPreferences = context.getSharedPreferences(
        "LuxeRentalsSession", 
        Context.MODE_PRIVATE
    )
    
    companion object {
        private const val KEY_IS_LOGGED_IN = "is_logged_in"
        private const val KEY_USER_ID = "user_id"
        private const val KEY_FULL_NAME = "full_name"
        private const val KEY_EMAIL = "email"
        private const val KEY_PHONE = "phone"
        private const val KEY_COUNTRY = "country"
        private const val KEY_IS_ADMIN = "is_admin"
    }
    
    /**
     * Save user login session
     */
    fun saveLoginSession(user: User) {
        val editor = prefs.edit()
        editor.putBoolean(KEY_IS_LOGGED_IN, true)
        editor.putInt(KEY_USER_ID, user.userId)
        editor.putString(KEY_FULL_NAME, user.fullName)
        editor.putString(KEY_EMAIL, user.email)
        editor.putString(KEY_PHONE, user.phone ?: "")
        editor.putString(KEY_COUNTRY, user.country ?: "")
        editor.putBoolean(KEY_IS_ADMIN, user.isAdmin)
        editor.apply() // Use apply() instead of commit() for async save
        
        // Also immediately commit to ensure it's saved
        editor.commit()
    }
    
    /**
     * Check if user is logged in
     */
    fun isLoggedIn(): Boolean {
        return prefs.getBoolean(KEY_IS_LOGGED_IN, false)
    }
    
    /**
     * Get user ID
     */
    fun getUserId(): Int {
        return prefs.getInt(KEY_USER_ID, 0)
    }
    
    /**
     * Get full name
     */
    fun getFullName(): String {
        return prefs.getString(KEY_FULL_NAME, "Guest") ?: "Guest"
    }
    
    /**
     * Get email
     */
    fun getEmail(): String {
        return prefs.getString(KEY_EMAIL, "") ?: ""
    }
    
    /**
     * Get phone
     */
    fun getPhone(): String {
        return prefs.getString(KEY_PHONE, "") ?: ""
    }
    
    /**
     * Get country
     */
    fun getCountry(): String {
        return prefs.getString(KEY_COUNTRY, "") ?: ""
    }
    
    /**
     * Check if user is admin
     */
    fun isAdmin(): Boolean {
        return prefs.getBoolean(KEY_IS_ADMIN, false)
    }
    
    /**
     * Logout user
     */
    fun logout() {
        val editor = prefs.edit()
        editor.clear()
        editor.apply()
        editor.commit()
    }
    
    /**
     * Get current user data as User object
     */
    fun getCurrentUser(): User? {
        if (!isLoggedIn()) return null
        
        return User(
            userId = getUserId(),
            fullName = getFullName(),
            email = getEmail(),
            phone = getPhone(),
            country = getCountry(),
            isAdmin = isAdmin(),
            accountStatus = "active"
        )
    }
}
