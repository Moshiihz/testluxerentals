package com.luxerentals.app.models

import com.google.gson.annotations.SerializedName

data class BookingData(
    @SerializedName("rentalId")
    val rentalId: Int,
    
    @SerializedName("vehicleName")
    val vehicleName: String,
    
    @SerializedName("startDate")
    val startDate: String,
    
    @SerializedName("endDate")
    val endDate: String,
    
    @SerializedName("totalDays")
    val totalDays: Int,
    
    @SerializedName("totalAmount")
    val totalAmount: Double
)
