package com.luxerentals.app.models

import com.google.gson.annotations.SerializedName

data class User(
    @SerializedName("user_id")
    val userId: Int,
    @SerializedName("full_name")
    val fullName: String,
    val email: String,
    val phone: String,
    val country: String,
    @SerializedName("is_admin")
    val isAdmin: Boolean = false,
    @SerializedName("account_status")
    val accountStatus: String
)
