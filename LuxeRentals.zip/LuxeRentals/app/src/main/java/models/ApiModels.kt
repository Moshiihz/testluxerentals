package com.luxerentals.app.models

import com.google.gson.annotations.SerializedName

data class ApiResponse<T>(
    val success: Boolean,
    val message: String,
    val data: T? = null
)

data class LoginResponse(
    val success: Boolean,
    val message: String?,
    val user: User?  // ← CORRECT!
)

data class SignupResponse(
    val success: Boolean,
    val message: String?,
    val user: User?  // ← CORRECT!
)

data class ActiveRentalResponse(
    val success: Boolean,
    val message: String?,
    @SerializedName("has_rental")
    val hasRental: Boolean = false,
    val rental: Rental?
)

data class RentalsResponse(
    val success: Boolean,
    val message: String,
    val rentals: List<Rental>?
)

data class BookingResponse(
    val success: Boolean,
    val message: String,
    val data: BookingData?
)

data class BookingHistoryResponse(
    val success: Boolean,
    val message: String,
    val rentals: List<Rental>?
)

data class EarningsResponse(
    val success: Boolean,
    val message: String,
    @SerializedName("today_earnings")
    val todayEarnings: Double = 0.0,
    @SerializedName("total_earnings")
    val totalEarnings: Double = 0.0,
    @SerializedName("monthly_earnings")
    val monthlyEarnings: Double = 0.0,
    @SerializedName("monthly_bookings")
    val monthlyBookings: Int = 0,
    val statistics: Statistics?
)

data class Statistics(
    @SerializedName("today_earnings")
    val todayEarnings: Double = 0.0,
    @SerializedName("total_earnings")
    val totalEarnings: Double = 0.0,
    @SerializedName("total_bookings")
    val totalBookings: Int = 0,
    @SerializedName("pending_bookings")
    val pendingBookings: Int = 0,
    @SerializedName("confirmed_bookings")
    val confirmedBookings: Int = 0,
    @SerializedName("approved_bookings")
    val approvedBookings: Int = 0,
    @SerializedName("active_bookings")
    val activeBookings: Int = 0,
    @SerializedName("completed_bookings")
    val completedBookings: Int = 0,
    @SerializedName("denied_bookings")
    val deniedBookings: Int = 0,
    @SerializedName("total_revenue")
    val totalRevenue: Double = 0.0
)

data class GenericResponse(
    val success: Boolean,
    val message: String
)
