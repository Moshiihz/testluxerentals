package com.luxerentals.app.models

import com.google.gson.annotations.SerializedName
import java.util.Date

data class Rental(
    @SerializedName("rentalId")
    val rentalId: Int,
    @SerializedName("userId")
    val userId: Int,
    @SerializedName("vehicleId")
    val vehicleId: Int,
    @SerializedName("vehicleBrand")
    val vehicleBrand: String,
    @SerializedName("vehicleModel")
    val vehicleModel: String,
    @SerializedName("userName")
    val userName: String,
    @SerializedName("startDate")
    val startDate: Date,
    @SerializedName("endDate")
    val endDate: Date,
    @SerializedName("pickupLocation")
    val pickupLocation: String,
    @SerializedName("dropoffLocation")
    val dropoffLocation: String,
    @SerializedName("totalDays")
    val totalDays: Int,
    @SerializedName("dailyRate")
    val dailyRate: Double,
    @SerializedName("totalAmount")
    val totalAmount: Double,
    @SerializedName("depositAmount")
    val depositAmount: Double,
    val status: String
) {
    fun getFormattedTotal(): String {
        return String.format("₱%.2f", totalAmount)
    }
    
    fun getStatusColor(): Int {
        return when (status.lowercase()) {
            "pending" -> 0xFFFFB800.toInt()
            "confirmed" -> 0xFF10B981.toInt()
            "active" -> 0xFF3B82F6.toInt()
            "approved" -> 0xFF10B981.toInt()
            "completed" -> 0xFF10B981.toInt()
            "cancelled" -> 0xFFEF4444.toInt()
            "denied" -> 0xFFEF4444.toInt()
            else -> 0xFF6B7280.toInt()
        }
    }
}
