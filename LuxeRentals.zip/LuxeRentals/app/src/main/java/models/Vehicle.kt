package com.luxerentals.app.models

import com.google.gson.annotations.SerializedName

data class Vehicle(
    @SerializedName("vehicleId")
    val vehicleId: Int,
    val brand: String,
    val model: String,
    val year: Int,
    val category: String,
    @SerializedName("dailyRate")
    val dailyRate: Double,
    val seats: Int,
    val transmission: String,
    @SerializedName("fuelType")
    val fuelType: String,
    @SerializedName("plateNumber")
    val plateNumber: String,
    val color: String,
    val status: String,
    @SerializedName("imageUrl")
    val imageUrl: String?
) {
    fun getDisplayName(): String {
        return "$brand $model"
    }
    
    fun getFormattedPrice(): String {
        return String.format("₱%.2f/day", dailyRate)
    }
}
