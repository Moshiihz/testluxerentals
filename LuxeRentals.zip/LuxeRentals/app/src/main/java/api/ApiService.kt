package com.luxerentals.app.api

import com.luxerentals.app.models.*
import retrofit2.Response
import retrofit2.http.*

interface ApiService {
    
    // Authentication
    @POST("login.php")
    suspend fun login(@Body credentials: Map<String, String>): Response<LoginResponse>
    
    @POST("signup.php")
    suspend fun signup(@Body userData: Map<String, String>): Response<SignupResponse>
    
    // Vehicles
    @GET("book_vehicle.php")
    suspend fun getAvailableVehicles(): Response<List<Vehicle>>
    
    @GET("admin_vehicles.php")
    suspend fun getAllVehicles(): Response<List<Vehicle>>
    
    @POST("delete_vehicle.php")
    suspend fun deleteVehicle(@Query("vehicle_id") vehicleId: Int): Response<GenericResponse>
    
    // Rentals
    @GET("get_active_rental.php")
    suspend fun getActiveRental(@Query("user_id") userId: Int): Response<ActiveRentalResponse>
    
    @POST("book_rental.php")
    suspend fun createBooking(@Body bookingData: Map<String, String>): Response<BookingResponse>
    
    @POST("cancel_rental.php")
    suspend fun cancelRental(@Query("rental_id") rentalId: Int): Response<GenericResponse>
    
    // Admin
    @GET("admin_dashboard.php")
    suspend fun getAllRentals(): Response<RentalsResponse>
    
    @POST("approve_rental.php")
    suspend fun approveRental(
        @Query("rental_id") rentalId: Int,
        @Query("action") action: String
    ): Response<GenericResponse>
    
    @POST("delete_booking.php")
    suspend fun deleteBooking(@Query("rental_id") rentalId: Int): Response<GenericResponse>
    
    @GET("get_earnings.php")
    suspend fun getEarnings(): Response<EarningsResponse>
}
